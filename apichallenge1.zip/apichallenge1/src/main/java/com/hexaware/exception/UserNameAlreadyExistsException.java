package com.hexaware.exception;

public class UserNameAlreadyExistsException extends Exception {

	public UserNameAlreadyExistsException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
}
