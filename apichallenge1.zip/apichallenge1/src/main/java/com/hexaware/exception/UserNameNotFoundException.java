package com.hexaware.exception;

public class UserNameNotFoundException extends Exception {

	public UserNameNotFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
