import React from 'react';
import axios from 'axios';
import { message } from "antd";

import {LogoutOutlined} from '@ant-design/icons'
import { Layout, Menu } from 'antd';
import { useNavigate } from 'react-router-dom';

import { useContext } from 'react';
import DataContext from './DataContext.js';
import '../styles/Header.css'


import SignUp from './Signup.js';
import Login from './Login.js';

const { Header: AntHeader } = Layout;

const Header=()=>{
    const navigate=useNavigate()
    const {userDetails,setUserDetails,setToken,loginFlag,setLoginFlag,setSignupFlag}=useContext(DataContext);
    const handleMenuClick = (key) => {
        navigate(key);
      };
      
      const BASE_URL="http://localhost:8084/";
      const login=(email,password)=>{
        console.log("Logging In...")
        axios.post(BASE_URL+"user/login",{username:email,password})
        .then((res)=>{
          message.success("Login Successful")
          setToken(res.data.jwt);
          setUserDetails(res.data);
          setLoginFlag(true);
          localStorage.setItem("token",res.data.jwt)
          localStorage.setItem("user",JSON.stringify(res.data))
          console.log(res.data);
        })
        .catch((err)=>{
          message.error("Login Failed")
          console.log("Error During Login "+err)
      })
      }

      const logout=()=>{
        message.success("Logged Out")
        localStorage.removeItem("user");
        localStorage.removeItem("token");
    
        setUserDetails("");
        setToken("");
        console.log(userDetails);
      }
    
      const signup=(userdata)=>{
        console.log("signup")
        axios.post(BASE_URL+"user/signup",userdata)
        .then((res)=>{
          console.log("User registered Successful",res.data);
          setSignupFlag(true)
          message.success("Signup succesful")
        })
        .catch((err)=>{
          console.log("Error During Login "+err)
        message.error("Signup failed");    
      });
    }

    return(
        <>
        <AntHeader className="header">
            <Menu 
                theme="light" 
                mode="horizontal" 
                className="menu"
                onClick={({ key }) => handleMenuClick(key)}
                style={{minWidth:"800px", display:"flex", justifyContent:"center"}}
            >
            <Menu.Item key="/">Home</Menu.Item>
            {
                userDetails!==""?
                <><Menu.Item key="/books">Books</Menu.Item><Menu.Item key="/profile">Profile</Menu.Item></>
                :null
            }
                

            </Menu>
            {
                userDetails===""?
                <div className="header-btns">
                <SignUp signup={signup}/>
                <Login login={login} flag={loginFlag}/>
                </div>:
                <div className='user-details'>
                <p>{userDetails.userName.split('@')[0]}</p>
                <LogoutOutlined onClick={logout} className="logout-btn"/>
                </div>
            }

    </AntHeader>
        </>
    )
}
export default Header;