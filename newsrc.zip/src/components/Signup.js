import React, { useContext, useState,useEffect } from "react";
import { Modal, Button, Input, DatePicker, Radio, Form} from "antd";
import DataContext from "./DataContext";

// const { Text } = Typography;

const SignUp = ({signup}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();

  const {signupFlag,setSignupFlag}=useContext(DataContext)

  
  useEffect(()=>{
    if(signupFlag===false){
      setIsModalOpen(true);
    }
  },[signupFlag])

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onFinish = (values) => {
    console.log("Form values:", values);

     const userdata = {
        ...values,
        dob: values.dob.format("YYYY-MM-DD"),
        role:"ADMIN"
    };
    
  console.log(userdata);

  signup(userdata);
  setSignupFlag(true);
  setIsModalOpen(false);
};


return (
  <div>
    <Button onClick={showModal}>Sign Up</Button>
    <Modal
      title="Sign Up"
      open={isModalOpen}
      onCancel={handleCancel}
      footer={null}
      width={700}
    >
      <Form
        form={form}
        layout="vertical"
        onFinish={onFinish}
        initialValues={{ gender: "Male" }}
      >
        <div className="form-container">
            <div className="form-left">
                <Form.Item
                  label="Name"
                  name="name"
                  rules={[{ required: true, message: "Please enter your name" }]}
                >
                  <Input placeholder="Enter your name" />
                </Form.Item>

                <Form.Item
                  label="Email"
                  name="userName"
                  rules={[
                    { required: true, message: "Please enter your email" },
                    { type: "email", message: "Please enter a valid email address" },
                  ]}
                >
                  <Input placeholder="Enter your email" />
                </Form.Item>

                <Form.Item
                  label="Password"
                  name="password"
                  rules={[{ required: true, message: "Please enter your password" }]}
                >
                  <Input.Password placeholder="Enter your password" />
                </Form.Item>

                <Form.Item
                  label="Phone Number"
                  name="number"
                  rules={[
                    { required: true, message: "Please enter your phone number" },
                    {
                      pattern: /^[0-9]{10}$/,
                      message: "Enter a valid 10-digit number",
                    },
                  ]}
                >
                  <Input placeholder="Enter your phone number" />
                </Form.Item>
                </div>
                <div className="form-right">
                <Form.Item
                  label="Date of Birth"
                  name="dob"
                  rules={[
                    { required: true, message: "Please select your date of birth" },
                  ]}
                >
                  <DatePicker style={{ width: "100%" }} />
                </Form.Item>

                <Form.Item
                  label="Gender"
                  name="gender"
                  rules={[{ required: true, message: "Please select your gender" }]}
                >
                  <Radio.Group>
                    <Radio value="Male">Male</Radio>
                    <Radio value="Female">Female</Radio>
                    <Radio value="Other">Other</Radio>
                  </Radio.Group>
                </Form.Item>

                <Form.Item
                  label="City"
                  name="city"
                  rules={[
                    { required: true, message: "Please enter your city" },
                    {
                      pattern: /^[A-Za-z ]+$/,
                      message: "City should only contain alphabets and spaces",
                    },
                  ]}
                >
                  <Input placeholder="Enter your city" />
                </Form.Item>

                <Form.Item
                  label="State"
                  name="state"
                  rules={[
                    { required: true, message: "Please enter your state" },
                    {
                      pattern: /^[A-Za-z ]+$/,
                      message: "State should only contain alphabets and spaces",
                    },
                  ]}
                >
                  <Input placeholder="Enter your state" />
                </Form.Item>
                <Form.Item
                  label="Country"
                  name="country"
                  rules={[
                    { required: true, message: "Please enter your Country" },
                    {
                      pattern: /^[A-Za-z ]+$/,
                      message: "Country should only contain alphabets and spaces",
                    },
                  ]}
                >
                  <Input placeholder="Enter your Country" />
                </Form.Item>
                </div>
                </div>
        <Form.Item>
          <Button type="primary" htmlType="submit" block>
            Sign Up
          </Button>
        </Form.Item>
      </Form>
    </Modal>
  </div>
);
};

export default SignUp;