import {Route,Routes} from 'react-router-dom';
import Home from './Home';
import Books from './Books';

const Routing=()=>{
    return(
        <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path="/books" element={<Books/>}/>
        </Routes>
    )
}
export default Routing