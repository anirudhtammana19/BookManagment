import Header from "./Header";

const Home=()=>{
    return(
        <>
        <Header/>
        </>
    )
}
export default Home;